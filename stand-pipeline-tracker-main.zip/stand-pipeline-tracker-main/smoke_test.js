/**
 * Masvingo City Council Cadastral Workflow Engine
 * smoke_test.js — Automated verification of core requirements:
 * 1. Public /api/parcels returns valid GeoJSON FeatureCollection
 * 2. Malformed bbox returns 400 Bad Request
 * 3. SQL injection attempt matches 0 records without crashing
 * 4. Funnel analytical report accurately identifies bottleneck stage
 * 5. Database trigger blocks stage skipping without justification notes
 */

const BASE = process.env.BASE || 'http://localhost:3000';
let pass = 0;
let fail = 0;

async function check(description, fn) {
  try {
    await fn();
    console.log(`  [PASS] ${description}`);
    pass++;
  } catch (err) {
    console.error(`  [FAIL] ${description}\n         Error: ${err.message}`);
    fail++;
  }
}

function assert(condition, message) {
  if (!condition) {
    throw new Error(message || 'Assertion failed');
  }
}

async function request(path, options = {}) {
  const url = BASE + path;
  const res = await fetch(url, options);
  const isJson = res.headers.get('content-type')?.includes('json');
  const body = isJson ? await res.json() : await res.text();
  return { status: res.status, body };
}

async function runSmokeTests() {
  console.log('=====================================================');
  console.log('Masvingo Stand Pipeline Tracker — Automated Smoke Test');
  console.log(`Target API: ${BASE}`);
  console.log('=====================================================\n');

  // Test 1: Public /api/parcels returns a valid GeoJSON FeatureCollection
  await check('Public /api/parcels returns a valid GeoJSON FeatureCollection', async () => {
    const { status, body } = await request('/api/parcels');
    assert(status === 200, `Expected HTTP 200, received ${status}`);
    assert(body.type === 'FeatureCollection', `Expected FeatureCollection, received ${body.type}`);
    assert(Array.isArray(body.features), 'Expected features array');
    assert(body.features.length > 0, `Expected features > 0, got ${body.features.length}`);
    assert(body.numberMatched === 52, `Expected 52 parcels matched, got ${body.numberMatched}`);

    const firstFeature = body.features[0];
    assert(firstFeature.geometry && firstFeature.geometry.type === 'Polygon', 'Feature geometry must be Polygon');
    const coord = firstFeature.geometry.coordinates[0][0];
    assert(coord[0] > 30.5 && coord[0] < 31.2, `Longitude ${coord[0]} out of Masvingo bounds (30.5 to 31.2)`);
    assert(coord[1] < -19.8 && coord[1] > -20.5, `Latitude ${coord[1]} out of Masvingo bounds (-20.5 to -19.8)`);
    assert(firstFeature.properties.upi, 'Parcel must have UPI');
    assert(firstFeature.properties.township, 'Parcel must have township');
    assert(firstFeature.properties.current_stage, 'Parcel must have current_stage');
  });

  // Test 2: Malformed bounding box queries (?bbox=bad,coords) return HTTP 400 Bad Request
  await check('Malformed bounding box queries (?bbox=bad,coords) return HTTP 400 Bad Request', async () => {
    const { status, body } = await request('/api/parcels?bbox=bad,coords');
    assert(status === 400, `Expected HTTP 400, received ${status}`);
    assert(body.error && body.error.toLowerCase().includes('bbox'), `Expected bbox error message, got: ${JSON.stringify(body)}`);

    // Additional invalid bbox checks
    const badRange = await request('/api/parcels?bbox=31.0,-20.0,30.0,-20.5'); // minx > maxx
    assert(badRange.status === 400, `Expected HTTP 400 for inverted bbox, received ${badRange.status}`);
  });

  // Test 3: SQL injection string (' OR '1'='1) matches 0 records without crashing
  await check("SQL injection string (' OR '1'='1) matches 0 records without crashing", async () => {
    const injection = "' OR '1'='1";
    const { status, body } = await request(`/api/parcels?stage=${encodeURIComponent(injection)}`);
    assert(status === 200, `Expected HTTP 200, received ${status}`);
    assert(body.type === 'FeatureCollection', 'Server did not return FeatureCollection');
    assert(body.numberMatched === 0, `Expected 0 matches for SQL injection string, got ${body.numberMatched}`);
    assert(body.features.length === 0, `Expected 0 features returned, got ${body.features.length}`);
  });

  // Test 4: Funnel analytical report accurately identifies the bottleneck stage
  await check('Funnel analytical report accurately identifies the bottleneck stage', async () => {
    const { status, body } = await request('/api/reports/funnel');
    assert(status === 200, `Expected HTTP 200, received ${status}`);
    assert(body.total_stands === 52, `Expected total_stands to be 52, got ${body.total_stands}`);
    assert(Array.isArray(body.stages) && body.stages.length === 5, 'Expected 5 pipeline stages');
    assert(body.bottleneck_stage, 'Report must identify bottleneck_stage');
    assert(body.bottleneck_stage.drop_off > 0, `Bottleneck drop_off must be > 0, got ${body.bottleneck_stage.drop_off}`);
    assert(body.bottleneck_stage.description, 'Bottleneck must include descriptive analysis');
  });

  // Test 5: Database trigger blocks stage skipping without justification notes
  await check('Database trigger blocks stage skipping without justification notes', async () => {
    // 1. Login as clerk
    const loginRes = await request('/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username: 't_chuma', password: 'Masvingo2026!' })
    });
    assert(loginRes.status === 200, `Clerk login failed with status ${loginRes.status}`);
    const token = loginRes.body.token;
    assert(token, 'Missing JWT token from login response');

    // 2. Fetch a parcel currently in Stage 1 (LAYOUT_APPROVED)
    const parcelsRes = await request('/api/parcels?stage=LAYOUT_APPROVED&limit=1');
    assert(parcelsRes.body.features.length > 0, 'No parcel found in LAYOUT_APPROVED stage');
    const parcelId = parcelsRes.body.features[0].id;

    // 3. Attempt to skip stage 2 and jump directly to Stage 3 (ALLOCATED) without justification note
    const skipAttempt = await request(`/api/parcels/${parcelId}/advance`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify({
        to_stage: 'ALLOCATED' // Skipping SURVEYED!
        // No justification_note provided!
      })
    });

    assert(skipAttempt.status === 400, `Expected HTTP 400 for unauthorized stage skip, got ${skipAttempt.status}`);
    assert(
      skipAttempt.body.error && skipAttempt.body.error.toLowerCase().includes('justification note'),
      `Expected error to mention justification note, got: ${skipAttempt.body.error}`
    );

    // 4. Verify that with a valid audit justification note, stage skipping is permitted and logged
    const validSkip = await request(`/api/parcels/${parcelId}/advance`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify({
        to_stage: 'ALLOCATED',
        justification_note: 'Council Resolution MCC/2026/04: Special Ministerial fast-track allocation with cadastral survey waiver',
        source_doc_ref: 'MIN-DIR-2026-FST'
      })
    });

    assert(validSkip.status === 200, `Expected HTTP 200 when justification note is provided, got ${validSkip.status}`);
    assert(validSkip.body.parcel.current_stage === 'ALLOCATED', 'Parcel stage was not updated to ALLOCATED');
  });

  console.log('\n-----------------------------------------------------');
  console.log(`Results: ${pass} passed, ${fail} failed (Total: ${pass + fail})`);
  console.log('-----------------------------------------------------');

  if (fail > 0) {
    process.exit(1);
  }
}

runSmokeTests();
