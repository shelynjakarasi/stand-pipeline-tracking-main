/**
 * Masvingo City Council Cadastral Workflow Engine
 * server.js — RESTful API for Stand Pipeline Tracking and Cadastre Management
 */

require('dotenv').config();
const express = require('express');
const cors = require('cors');
const { Pool } = require('pg');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET || 'mcc_clis_secret_cadastre_key_2026_antigravity';

// Database connection pool
const pool = new Pool({
  connectionString: process.env.DATABASE_URL || `postgres://${process.env.PGUSER || 'postgres'}:${process.env.PGPASSWORD || 'postgres'}@${process.env.PGHOST || 'localhost'}:${process.env.PGPORT || 5432}/${process.env.PGDATABASE || 'masvingo_lis'}`
});

// Middleware
app.use(cors());
app.use(express.json());

// Security headers
app.use((req, res, next) => {
  res.set('X-Content-Type-Options', 'nosniff');
  res.set('X-Frame-Options', 'DENY');
  res.set('Referrer-Policy', 'no-referrer');
  res.set('Access-Control-Allow-Origin', '*');
  res.set('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  res.set('Access-Control-Allow-Methods', 'GET, POST, PATCH, OPTIONS');
  if (req.method === 'OPTIONS') return res.sendStatus(204);
  next();
});

// Serve static frontend files from project root
app.use(express.static(path.join(__dirname)));

// Load road network cache from heromero data if available
let cachedRoadsGeoJSON = null;
const roadsPath = path.join(__dirname, 'data', 'masvingo_roads.json');
if (fs.existsSync(roadsPath)) {
  try {
    cachedRoadsGeoJSON = JSON.parse(fs.readFileSync(roadsPath, 'utf-8'));
  } catch (e) {
    console.warn('Could not parse cached roads file:', e.message);
  }
}

// Authentication middleware
function authenticateToken(req, res, next) {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ error: 'Authentication required. Missing Bearer token.' });
  }

  jwt.verify(token, JWT_SECRET, (err, user) => {
    if (err) {
      return res.status(403).json({ error: 'Invalid or expired token.' });
    }
    req.user = user;
    next();
  });
}

// Authorization middleware for CLERK or ADMIN
function requireClerk(req, res, next) {
  if (!req.user || (req.user.role !== 'CLERK' && req.user.role !== 'ADMIN')) {
    return res.status(403).json({ error: 'Permission denied. Role CLERK or ADMIN required.' });
  }
  next();
}

// Helper: parse and validate BBOX
function parseBbox(s) {
  if (!s) return null;
  const parts = String(s).split(',').map(Number);
  if (parts.length !== 4 || parts.some(n => Number.isNaN(n))) {
    return false; // Malformed
  }
  const [minx, miny, maxx, maxy] = parts;
  if (minx < -180 || maxx > 180 || miny < -90 || maxy > 90 || minx >= maxx || miny >= maxy) {
    return false; // Out of bounds
  }
  return [minx, miny, maxx, maxy];
}

/* =====================================================================
 *  API ROUTES
 * ===================================================================== */

// Landing / Health check
app.get('/api', (req, res) => {
  res.json({
    title: 'Masvingo City Council Cadastral Workflow Engine API',
    version: '1.0.0',
    authority: 'Masvingo City Council / Midlands State University',
    srid: {
      storage: 'Arc 1950 Gauss 31°E (SRID 990031)',
      served: 'WGS 84 (EPSG 4326)'
    },
    endpoints: {
      auth: 'POST /api/auth/login',
      parcels: 'GET /api/parcels',
      single_parcel: 'GET /api/parcels/:id',
      advance_stage: 'POST /api/parcels/:id/advance',
      funnel_report: 'GET /api/reports/funnel',
      stalled_report: 'GET /api/reports/stalled',
      stages: 'GET /api/stages',
      roads: 'GET /api/basemap/roads'
    }
  });
});

// POST /api/auth/login — Clerk JWT generation
app.post('/api/auth/login', async (req, res) => {
  try {
    const { username, password } = req.body;
    if (!username || !password) {
      return res.status(400).json({ error: 'Username and password required.' });
    }

    const result = await pool.query(
      'SELECT username, password_hash, full_name, role, active FROM lis.app_user WHERE username = $1',
      [username]
    );

    if (result.rows.length === 0) {
      return res.status(401).json({ error: 'Invalid username or password.' });
    }

    const user = result.rows[0];
    if (!user.active) {
      return res.status(403).json({ error: 'Account is deactivated.' });
    }

    const isValid = bcrypt.compareSync(password, user.password_hash);
    if (!isValid) {
      return res.status(401).json({ error: 'Invalid username or password.' });
    }

    const token = jwt.sign(
      {
        username: user.username,
        full_name: user.full_name,
        role: user.role
      },
      JWT_SECRET,
      { expiresIn: '24h' }
    );

    res.json({
      token,
      user: {
        username: user.username,
        full_name: user.full_name,
        role: user.role
      }
    });
  } catch (err) {
    console.error('Login error:', err);
    res.status(500).json({ error: 'Internal server error during authentication.' });
  }
});

// GET /api/stages — Return stages lookup
app.get('/api/stages', async (req, res) => {
  try {
    const result = await pool.query('SELECT code, seq, name, color, description FROM lis_ref.stage ORDER BY seq;');
    res.json(result.rows);
  } catch (err) {
    console.error('Stages error:', err);
    res.status(500).json({ error: 'Failed to retrieve stages.' });
  }
});

// GET /api/parcels — OGC-compliant GeoJSON FeatureCollection
app.get('/api/parcels', async (req, res) => {
  try {
    const { stage, township, stalled, search, bbox, limit = 200, offset = 0 } = req.query;

    const conditions = [];
    const params = [];

    // Stage filter
    if (stage) {
      params.push(stage);
      conditions.push(`v.current_stage = $${params.length}`);
    }

    // Township filter
    if (township) {
      params.push(township);
      conditions.push(`v.township = $${params.length}`);
    }

    // Stalled filter
    if (stalled !== undefined && stalled !== '') {
      const isStalled = stalled === 'true' || stalled === '1';
      conditions.push(isStalled ? `v.is_stalled = true` : `v.is_stalled = false`);
    }

    // Search filter
    if (search) {
      params.push(`%${search}%`);
      conditions.push(`(v.upi ILIKE $${params.length} OR v.stand_no ILIKE $${params.length})`);
    }

    // Bbox filter
    if (bbox) {
      const parsedBox = parseBbox(bbox);
      if (parsedBox === false) {
        return res.status(400).json({
          error: 'Invalid bbox query parameter. Expected minx,miny,maxx,maxy in WGS84 coordinates.'
        });
      }
      const [minx, miny, maxx, maxy] = parsedBox;
      params.push(minx, miny, maxx, maxy);
      const idx = params.length - 3;
      conditions.push(`ST_Intersects(v.geom, ST_Transform(ST_MakeEnvelope($${idx}, $${idx+1}, $${idx+2}, $${idx+3}, 4326), 990031))`);
    }

    const whereClause = conditions.length > 0 ? `WHERE ${conditions.join(' AND ')}` : '';

    // Total matched count
    const countQuery = `SELECT count(*)::int AS total FROM lis.v_parcels_public v ${whereClause};`;
    const countRes = await pool.query(countQuery, params);
    const numberMatched = countRes.rows[0].total;

    // Fetch GeoJSON features
    const dataQuery = `
      SELECT 
        v.id,
        v.upi,
        v.township,
        v.stand_no,
        v.area_m2,
        v.current_stage,
        v.stage_name,
        v.stage_seq,
        v.stage_color,
        v.stage_entered_at,
        v.months_in_stage,
        v.is_stalled,
        ST_AsGeoJSON(ST_Transform(v.geom, 4326))::json AS geometry
      FROM lis.v_parcels_public v
      ${whereClause}
      ORDER BY v.id ASC
      LIMIT $${params.length + 1} OFFSET $${params.length + 2};
    `;

    const paginationParams = [...params, Math.min(Math.max(parseInt(limit, 10) || 100, 1), 500), Math.max(parseInt(offset, 10) || 0, 0)];
    const dataRes = await pool.query(dataQuery, paginationParams);

    const features = dataRes.rows.map(row => ({
      type: 'Feature',
      id: row.id,
      geometry: row.geometry,
      properties: {
        id: row.id,
        upi: row.upi,
        township: row.township,
        stand_no: row.stand_no,
        area_m2: parseFloat(row.area_m2),
        current_stage: row.current_stage,
        stage_name: row.stage_name,
        stage_seq: row.stage_seq,
        stage_color: row.stage_color,
        stage_entered_at: row.stage_entered_at,
        months_in_stage: parseFloat(row.months_in_stage),
        is_stalled: row.is_stalled
      }
    }));

    res.json({
      type: 'FeatureCollection',
      numberMatched,
      numberReturned: features.length,
      features
    });
  } catch (err) {
    console.error('Parcels error:', err);
    res.status(500).json({ error: 'Failed to retrieve parcels GeoJSON.' });
  }
});

// GET /api/parcels/:id — Full parcel metadata & historical stage events
app.get('/api/parcels/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const isNum = !isNaN(id);

    const parcelQuery = `
      SELECT 
        v.id,
        v.upi,
        v.township,
        v.stand_no,
        v.area_m2,
        v.current_stage,
        v.stage_name,
        v.stage_seq,
        v.stage_color,
        v.stage_entered_at,
        v.months_in_stage,
        v.is_stalled,
        ST_AsGeoJSON(ST_Transform(v.geom, 4326))::json AS geometry
      FROM lis.v_parcels_public v
      WHERE ${isNum ? 'v.id = $1' : 'v.upi = $1'};
    `;
    const parcelRes = await pool.query(parcelQuery, [id]);

    if (parcelRes.rows.length === 0) {
      return res.status(404).json({ error: 'Parcel not found.' });
    }

    const parcel = parcelRes.rows[0];

    // Fetch chronological event log
    const eventsQuery = `
      SELECT 
        e.id,
        e.from_stage,
        s1.name AS from_stage_name,
        e.to_stage,
        s2.name AS to_stage_name,
        s2.color AS to_stage_color,
        e.event_date,
        e.recorded_by,
        e.justification_note,
        e.source_doc_ref,
        e.created_at
      FROM lis.stage_event e
      LEFT JOIN lis_ref.stage s1 ON e.from_stage = s1.code
      JOIN lis_ref.stage s2 ON e.to_stage = s2.code
      WHERE e.parcel_id = $1
      ORDER BY e.event_date ASC, e.id ASC;
    `;
    const eventsRes = await pool.query(eventsQuery, [parcel.id]);

    res.json({
      parcel: {
        id: parcel.id,
        upi: parcel.upi,
        township: parcel.township,
        stand_no: parcel.stand_no,
        area_m2: parseFloat(parcel.area_m2),
        current_stage: parcel.current_stage,
        stage_name: parcel.stage_name,
        stage_seq: parcel.stage_seq,
        stage_color: parcel.stage_color,
        stage_entered_at: parcel.stage_entered_at,
        months_in_stage: parseFloat(parcel.months_in_stage),
        is_stalled: parcel.is_stalled,
        geometry: parcel.geometry
      },
      events: eventsRes.rows
    });
  } catch (err) {
    console.error('Parcel detail error:', err);
    res.status(500).json({ error: 'Failed to retrieve parcel details.' });
  }
});

// POST /api/parcels/:id/advance — Clerk stage advancement with trigger validation
app.post('/api/parcels/:id/advance', authenticateToken, requireClerk, async (req, res) => {
  const client = await pool.connect();
  try {
    const { id } = req.params;
    const { to_stage, justification_note, source_doc_ref } = req.body;

    if (!to_stage) {
      return res.status(400).json({ error: 'Target stage (to_stage) is required.' });
    }

    const isNum = !isNaN(id);
    const parcelRes = await client.query(
      `SELECT id, upi, current_stage FROM lis.parcel WHERE ${isNum ? 'id = $1' : 'upi = $1'};`,
      [id]
    );

    if (parcelRes.rows.length === 0) {
      return res.status(404).json({ error: 'Parcel not found.' });
    }

    const parcel = parcelRes.rows[0];

    // Insert into lis.stage_event.
    // The database trigger 'trg_stage_event_sync' will validate sequential progression
    // and update lis.parcel automatically.
    const eventQuery = `
      INSERT INTO lis.stage_event (
        parcel_id,
        from_stage,
        to_stage,
        event_date,
        recorded_by,
        justification_note,
        source_doc_ref
      )
      VALUES ($1, $2, $3, now(), $4, $5, $6)
      RETURNING *;
    `;

    const eventRes = await client.query(eventQuery, [
      parcel.id,
      parcel.current_stage,
      to_stage,
      req.user.username,
      justification_note || null,
      source_doc_ref || null
    ]);

    // Fetch updated parcel
    const updatedParcelRes = await client.query(
      `SELECT * FROM lis.v_parcels_public WHERE id = $1;`,
      [parcel.id]
    );

    res.json({
      message: `Stand ${parcel.upi} successfully advanced to stage ${to_stage}.`,
      parcel: updatedParcelRes.rows[0],
      event: eventRes.rows[0]
    });
  } catch (err) {
    // Check if error was raised by our database trigger
    if (err.code === '23514' || err.message.includes('trigger') || err.message.includes('justification note') || err.message.includes('Stage skipping')) {
      return res.status(400).json({
        error: err.message,
        trigger_violation: true
      });
    }
    console.error('Advance stage error:', err);
    res.status(500).json({ error: 'Failed to advance parcel stage: ' + err.message });
  } finally {
    client.release();
  }
});

// GET /api/reports/funnel — Stage counts, drop-offs, and bottleneck stage calculation
app.get('/api/reports/funnel', async (req, res) => {
  try {
    const stagesRes = await pool.query('SELECT code, seq, name, color FROM lis_ref.stage ORDER BY seq;');
    const stages = stagesRes.rows;

    const countRes = await pool.query(`
      SELECT current_stage, count(*)::int AS count
      FROM lis.parcel
      GROUP BY current_stage;
    `);

    const countMap = {};
    for (const row of countRes.rows) {
      countMap[row.current_stage] = row.count;
    }

    const totalStandsRes = await pool.query('SELECT count(*)::int AS total FROM lis.parcel;');
    const totalStands = totalStandsRes.rows[0].total;

    // Calculate funnel progression and drop-offs
    let maxDropOff = -1;
    let bottleneckStage = null;

    const funnelStages = [];
    for (let i = 0; i < stages.length; i++) {
      const s = stages[i];
      const count = countMap[s.code] || 0;
      
      let dropOff = 0;
      if (i > 0) {
        const prevCount = countMap[stages[i - 1].code] || 0;
        dropOff = prevCount - count;
        if (dropOff > maxDropOff) {
          maxDropOff = dropOff;
          bottleneckStage = {
            from_stage: stages[i - 1].code,
            from_stage_name: stages[i - 1].name,
            to_stage: s.code,
            to_stage_name: s.name,
            drop_off: dropOff,
            description: `Largest drop-off observed between "${stages[i - 1].name}" and "${s.name}" (${dropOff} stands drop-off).`
          };
        }
      }

      funnelStages.push({
        code: s.code,
        name: s.name,
        seq: s.seq,
        color: s.color,
        count,
        percentage: totalStands > 0 ? Math.round((count / totalStands) * 100) : 0,
        drop_off: dropOff
      });
    }

    res.json({
      total_stands: totalStands,
      bottleneck_stage: bottleneckStage || {
        description: 'Pipeline operating with balanced progression.'
      },
      stages: funnelStages
    });
  } catch (err) {
    console.error('Funnel report error:', err);
    res.status(500).json({ error: 'Failed to generate funnel report.' });
  }
});

// GET /api/reports/stalled?months=12 — Parcels exceeding stage age thresholds
app.get('/api/reports/stalled', async (req, res) => {
  try {
    const months = parseInt(req.query.months, 10) || 12;

    const query = `
      SELECT 
        v.id,
        v.upi,
        v.township,
        v.stand_no,
        v.area_m2,
        v.current_stage,
        v.stage_name,
        v.stage_seq,
        v.stage_color,
        v.stage_entered_at,
        v.months_in_stage,
        e.recorded_by AS last_clerk,
        e.source_doc_ref
      FROM lis.v_parcels_public v
      LEFT JOIN LATERAL (
        SELECT recorded_by, source_doc_ref 
        FROM lis.stage_event 
        WHERE parcel_id = v.id 
        ORDER BY event_date DESC LIMIT 1
      ) e ON true
      WHERE v.stage_entered_at < (now() - ($1 || ' months')::interval)
      ORDER BY v.stage_entered_at ASC;
    `;

    const result = await pool.query(query, [months]);

    res.json({
      threshold_months: months,
      count: result.rows.length,
      stands: result.rows.map(r => ({
        id: r.id,
        upi: r.upi,
        township: r.township,
        stand_no: r.stand_no,
        area_m2: parseFloat(r.area_m2),
        current_stage: r.current_stage,
        stage_name: r.stage_name,
        stage_seq: r.stage_seq,
        stage_color: r.stage_color,
        stage_entered_at: r.stage_entered_at,
        months_in_stage: parseFloat(r.months_in_stage),
        last_clerk: r.last_clerk,
        source_doc_ref: r.source_doc_ref
      }))
    });
  } catch (err) {
    console.error('Stalled report error:', err);
    res.status(500).json({ error: 'Failed to generate stalled stands report.' });
  }
});

// GET /api/basemap/roads — Road vectors from heromero directory
app.get('/api/basemap/roads', (req, res) => {
  if (cachedRoadsGeoJSON) {
    res.set('Cache-Control', 'public, max-age=86400');
    return res.json(cachedRoadsGeoJSON);
  }
  res.status(404).json({ error: 'Road network vector layer not found.' });
});

// GET /api/basemap/dwg — AutoCAD BaseMap 2023 GeoJSON vectors (from BaseMap 2023 june.dwg)
const dwgBasemapPath = path.join(__dirname, 'data', 'masvingo_dwg_basemap.json');
app.get('/api/basemap/dwg', (req, res) => {
  if (fs.existsSync(dwgBasemapPath)) {
    res.set('Cache-Control', 'public, max-age=86400');
    return res.sendFile(dwgBasemapPath);
  }
  res.status(404).json({ error: 'AutoCAD BaseMap vector layer not found.' });
});

// GET /api/basemap/dwg-info — AutoCAD DWG metadata and layers
app.get('/api/basemap/dwg-info', (req, res) => {
  res.json({
    filename: 'BaseMap 2023 june.dwg',
    format: 'AutoCAD 2018-2023 (AC1032)',
    crs: 'Arc 1950 Gauss Conform 31°E (SRID 990031)',
    total_entities: 94093,
    active_cadastral_lines: 24735,
    key_layers: [
      { name: '6105Stands', count: 550, desc: 'Registered stand boundaries' },
      { name: 'new stand', count: 329, desc: 'Approved new allocations' },
      { name: 'RujekoFrame', count: 261, desc: 'Rujeko township cadastre frame' },
      { name: 'MuchekeFrame', count: 80, desc: 'Mucheke township cadastre frame' },
      { name: 'Bounds', count: 51, desc: 'Masvingo municipal boundary' },
      { name: 'cso42', count: 2663, desc: 'Council Survey Order 42' },
      { name: 'cso275-1', count: 992, desc: 'Council Survey Order 275-1' },
      { name: 'ward5', count: 190, desc: 'Ward 5 administrative boundary' },
      { name: 'oldRhodene', count: 11, desc: 'Old Rhodene boundary markers' }
    ]
  });
});

// Start API Server
app.listen(PORT, () => {
  console.log(`Masvingo Stand Pipeline Tracker API running on http://localhost:${PORT}`);
});
