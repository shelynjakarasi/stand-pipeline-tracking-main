/**
 * Masvingo City Council Cadastral Workflow Engine
 * seed.js — Seeds 52 authentic parcels across Mucheke, Rujeko, Rhodene, Target Kopje,
 * along with stages, default GIS Clerk (t_chuma), and historical stage events.
 */

require('dotenv').config();
const { Pool } = require('pg');
const bcrypt = require('bcryptjs');
const fs = require('fs');
const path = require('path');

const pool = new Pool({
  connectionString: process.env.DATABASE_URL || `postgres://${process.env.PGUSER || 'postgres'}:${process.env.PGPASSWORD || 'postgres'}@${process.env.PGHOST || 'localhost'}:${process.env.PGPORT || 5432}/${process.env.PGDATABASE || 'masvingo_lis'}`
});

async function seed() {
  console.log('--- Starting Stand Pipeline Seeding ---');

  const client = await pool.connect();
  try {
    await client.query('BEGIN');

    // 1. Seed Clerk and Administrative Users
    const salt = bcrypt.genSaltSync(10);
    const clerkPasswordHash = bcrypt.hashSync('Masvingo2026!', salt);

    await client.query(`
      INSERT INTO lis.app_user (username, password_hash, full_name, role, active)
      VALUES 
        ('t_chuma', $1, 'Tendai Chuma', 'CLERK', true),
        ('admin', $1, 'Chief Cadastral Officer', 'ADMIN', true),
        ('viewer', $1, 'Public Inquiries Desk', 'VIEWER', true)
      ON CONFLICT (username) DO UPDATE 
      SET password_hash = EXCLUDED.password_hash,
          full_name = EXCLUDED.full_name,
          role = EXCLUDED.role;
    `, [clerkPasswordHash]);

    // 2. Clear existing parcels and stage events
    await client.query('DELETE FROM lis.stage_event;');
    await client.query('DELETE FROM lis.parcel;');

    // 3. Load authentic parcel polygons extracted from heromero/heromero/AlphaListUpdated.shp
    const rawParcelsPath = path.join(__dirname, 'data', 'raw_parcels.json');
    let rawParcels = [];
    if (fs.existsSync(rawParcelsPath)) {
      rawParcels = JSON.parse(fs.readFileSync(rawParcelsPath, 'utf-8'));
    }

    if (rawParcels.length < 52) {
      throw new Error(`Expected at least 52 parcels in raw_parcels.json, found ${rawParcels.length}`);
    }

    // Stages sequence:
    // 1: LAYOUT_APPROVED (18 stands)
    // 2: SURVEYED        (15 stands)
    // 3: ALLOCATED       (9 stands)
    // 4: VALUATION_ROLL  (6 stands)
    // 5: TITLED          (4 stands)
    // Total: 52 stands
    const stageAllocations = [
      { code: 'LAYOUT_APPROVED', count: 18, stalledCount: 4 },
      { code: 'SURVEYED',        count: 15, stalledCount: 3 },
      { code: 'ALLOCATED',       count: 9,  stalledCount: 2 },
      { code: 'VALUATION_ROLL',  count: 6,  stalledCount: 1 },
      { code: 'TITLED',          count: 4,  stalledCount: 0 }
    ];

    const parcelStagePlan = [];
    for (const alloc of stageAllocations) {
      for (let i = 0; i < alloc.count; i++) {
        parcelStagePlan.push({
          targetStage: alloc.code,
          isStalled: i < alloc.stalledCount
        });
      }
    }

    console.log("Inserting 52 parcels into 'lis.parcel'...");

    // Township prefixes
    const townshipCodes = {
      'Mucheke': 'MUC',
      'Rujeko': 'RUJ',
      'Rhodene': 'RHO',
      'Target Kopje': 'TKP'
    };

    const standCounters = {
      'Mucheke': 100,
      'Rujeko': 200,
      'Rhodene': 300,
      'Target Kopje': 400
    };

    const stageHierarchy = ['LAYOUT_APPROVED', 'SURVEYED', 'ALLOCATED', 'VALUATION_ROLL', 'TITLED'];

    for (let i = 0; i < 52; i++) {
      const raw = rawParcels[i];
      const township = raw.township;
      standCounters[township]++;
      const standNo = String(standCounters[township]);
      const upi = `ZW-MV-${townshipCodes[township]}-${standNo}`;
      const plan = parcelStagePlan[i];

      // GeoJSON Polygon
      const geojsonPoly = {
        type: 'Polygon',
        coordinates: [raw.ring]
      };

      // Determine stage entry date
      const now = new Date();
      let stageEnteredAt;
      if (plan.isStalled) {
        // Stalled between 13 and 26 months ago
        const monthsAgo = 13 + (i % 12);
        stageEnteredAt = new Date(now.getTime() - monthsAgo * 30.5 * 24 * 3600 * 1000);
      } else {
        // Active between 1 and 7 months ago
        const monthsAgo = 1 + (i % 6);
        stageEnteredAt = new Date(now.getTime() - monthsAgo * 30.5 * 24 * 3600 * 1000);
      }

      const targetStageIndex = stageHierarchy.indexOf(plan.targetStage);
      const startDate = new Date(stageEnteredAt.getTime() - (targetStageIndex * 90 * 24 * 3600 * 1000));

      // Insert Parcel with ST_Transform from WGS84 to Arc 1950 Gauss 31°E (SRID 990031)
      const parcelRes = await client.query(`
        INSERT INTO lis.parcel (
          upi,
          township,
          stand_no,
          area_m2,
          current_stage,
          stage_entered_at,
          geom
        )
        VALUES (
          $1,
          $2,
          $3,
          $4,
          $5,
          $6,
          ST_Transform(ST_SetSRID(ST_GeomFromGeoJSON($7), 4326), 990031)
        )
        RETURNING id;
      `, [
        upi,
        township,
        standNo,
        raw.approx_area_m2 || 350.0,
        'LAYOUT_APPROVED',
        startDate,
        JSON.stringify(geojsonPoly)
      ]);

      const parcelId = parcelRes.rows[0].id;

      // Update calculated area from authoritative PostGIS geometry
      await client.query(`
        UPDATE lis.parcel
        SET area_m2 = ROUND(ST_Area(geom)::numeric, 1)
        WHERE id = $1;
      `, [parcelId]);

      let eventDate = new Date(stageEnteredAt.getTime() - (targetStageIndex * 90 * 24 * 3600 * 1000));

      for (let s = 0; s <= targetStageIndex; s++) {
        const toStage = stageHierarchy[s];
        const fromStage = s === 0 ? null : stageHierarchy[s - 1];
        const thisEventDate = (s === targetStageIndex) ? stageEnteredAt : new Date(eventDate.getTime() + (s * 75 * 24 * 3600 * 1000));

        let note = null;
        let docRef = `MCC-PLN-${townshipCodes[township]}-2024-${standNo}`;
        if (s === 1) docRef = `SG-SURV-31E-2025-${standNo}`;
        if (s === 2) docRef = `MCC-HSG-ALLOC-2025-${standNo}`;
        if (s === 3) docRef = `MCC-VAL-ROLL-2026-${standNo}`;
        if (s === 4) docRef = `DEEDS-REG-MV-2026-${standNo}`;

        // Disable trigger temporarily during initial history seeding to preserve historical entry dates
        await client.query(`
          INSERT INTO lis.stage_event (
            parcel_id,
            from_stage,
            to_stage,
            event_date,
            recorded_by,
            justification_note,
            source_doc_ref
          )
          VALUES ($1, $2, $3, $4, $5, $6, $7);
        `, [
          parcelId,
          fromStage,
          toStage,
          thisEventDate,
          't_chuma',
          note,
          docRef
        ]);
      }
    }

    await client.query('COMMIT');
    console.log('Seeding finished successfully.');
  } catch (err) {
    await client.query('ROLLBACK');
    console.error('Seeding failed:', err);
    process.exit(1);
  } finally {
    client.release();
    await pool.end();
  }
}

seed();
