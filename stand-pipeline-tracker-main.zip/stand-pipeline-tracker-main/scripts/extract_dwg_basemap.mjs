import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { LibreDwg, Dwg_File_Type } from '@mlightcad/libredwg-web';
import pg from 'pg';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const pool = new pg.Pool({
  connectionString: process.env.DATABASE_URL || 'postgres://postgres:postgres@localhost:5432/masvingo_lis'
});

async function extractDwgBasemap() {
  console.log('--- Extracting AutoCAD BaseMap 2023 June ---');
  console.log('Initializing LibreDwg parser...');
  const libredwg = await LibreDwg.create();

  const dwgPath = path.join(__dirname, '..', 'base map', 'base map', 'BaseMap 2023 june.dwg');
  console.log('Reading:', dwgPath);
  const buffer = fs.readFileSync(dwgPath);
  const dwg = libredwg.dwg_read_data(new Uint8Array(buffer), Dwg_File_Type.DWG);

  if (!dwg) {
    throw new Error('Failed to read DWG data');
  }

  console.log('Converting DWG data to entities model...');
  const model = libredwg.convert(dwg);
  console.log('Total entities in DWG:', model.entities.length);

  // Group lines by layer
  const targetLayers = new Set([
    'cso42', 'cso275-1', '6105Stands', 'new stand', 'RujekoFrame', 'MuchekeFrame',
    'oldRhodene', 'Bounds', 'Cadastral', 'ward5', 'CSO288', 'CSO86', 'CSO74',
    'CSO85', 'CSO087', 'CSO273', 'CSO313', 'CSO88', 'CSO84', 'cso290', '7495Stands',
    'Rw FRAME', 'RujekoFrame1', 'cso304-307', 'CS0285', 'CSO217', 'CSO367', 'Bounds',
    'LINE1', 'LINE3', 'Frame', 'PEN1'
  ]);

  const rawLines = [];
  for (let i = 0; i < model.entities.length; i++) {
    const e = model.entities[i];
    if (e.type === 'LINE' && e.startPoint && e.endPoint) {
      const layer = e.layer || '0';
      if (targetLayers.has(layer) || rawLines.length < 15000) {
        const x1 = Math.abs(e.startPoint.x);
        const y1 = Math.abs(e.startPoint.y);
        const x2 = Math.abs(e.endPoint.x);
        const y2 = Math.abs(e.endPoint.y);

        // Filter valid Masvingo Gauss coordinate bounds (X approx 10000..30000, Y approx 2210000..2240000)
        if (x1 > 5000 && x1 < 45000 && y1 > 2200000 && y1 < 2250000 &&
            x2 > 5000 && x2 < 45000 && y2 > 2200000 && y2 < 2250000) {
          rawLines.push({
            layer,
            x1, y1, x2, y2
          });
        }
      }
    }
  }

  console.log(`Filtered ${rawLines.length} cadastral lines in Masvingo coordinate bounds.`);
  libredwg.dwg_free(dwg);

  // Batch transform using PostGIS
  console.log('Transforming coordinates via PostGIS SRID 990031 -> WGS84...');
  const client = await pool.connect();
  const features = [];

  const BATCH_SIZE = 1000;
  for (let b = 0; b < rawLines.length; b += BATCH_SIZE) {
    const chunk = rawLines.slice(b, b + BATCH_SIZE);
    
    // Construct VALUES string
    const valuesClauses = chunk.map((line, idx) => 
      `(${idx}, '${line.layer}', ST_Transform(ST_SetSRID(ST_MakeLine(ST_Point(${line.x1}, ${line.y1}), ST_Point(${line.x2}, ${line.y2})), 990031), 4326))`
    ).join(',\n');

    const sql = `
      SELECT id, layer, ST_AsGeoJSON(geom)::json AS geom_json
      FROM (VALUES ${valuesClauses}) AS t(id, layer, geom);
    `;

    const res = await client.query(sql);
    for (const r of res.rows) {
      features.push({
        type: 'Feature',
        geometry: r.geom_json,
        properties: {
          layer: r.layer,
          source: 'AutoCAD BaseMap 2023 June'
        }
      });
    }
    process.stdout.write(`\rTransformed ${features.length} / ${rawLines.length} lines...`);
  }
  console.log('');
  client.release();
  await pool.end();

  const outGeoJSON = {
    type: 'FeatureCollection',
    name: 'Masvingo City Council AutoCAD BaseMap 2023 June',
    crs: { type: 'name', properties: { name: 'urn:ogc:def:crs:OGC:1.3:CRS84' } },
    features
  };

  const outPath = path.join(__dirname, '..', 'data', 'masvingo_dwg_basemap.json');
  fs.writeFileSync(outPath, JSON.stringify(outGeoJSON));
  console.log(`Successfully saved ${features.length} AutoCAD features to: ${outPath}`);
}

extractDwgBasemap().catch(e => {
  console.error('Extraction failed:', e);
  process.exit(1);
});
