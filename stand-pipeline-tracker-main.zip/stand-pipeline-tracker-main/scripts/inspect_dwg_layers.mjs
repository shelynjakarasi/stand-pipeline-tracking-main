import fs from 'fs';
import { LibreDwg, Dwg_File_Type } from '@mlightcad/libredwg-web';

async function listAllLayers() {
  const libredwg = await LibreDwg.create();
  const buffer = fs.readFileSync('base map/base map/BaseMap 2023 june.dwg');
  const dwg = libredwg.dwg_read_data(new Uint8Array(buffer), Dwg_File_Type.DWG);
  const model = libredwg.convert(dwg);

  const layers = {};
  for (let i = 0; i < model.entities.length; i++) {
    const l = model.entities[i].layer || 'default';
    layers[l] = (layers[l] || 0) + 1;
  }
  console.log('All DWG Layers in BaseMap 2023 june.dwg:');
  const sorted = Object.entries(layers).sort((a,b) => b[1] - a[1]);
  for (const [k, v] of sorted) {
    console.log('  Layer: ' + k + ' => ' + v + ' entities');
  }
  libredwg.dwg_free(dwg);
}

listAllLayers().catch(e => console.error(e));
