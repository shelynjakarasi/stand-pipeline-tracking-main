-- =====================================================================
--  Masvingo City Council Cadastral Workflow Engine
--  schema.sql — Stand Pipeline Tracker Core Database Schema
--  Midlands State University / Masvingo City Council Cadastre LIS
-- =====================================================================

CREATE EXTENSION IF NOT EXISTS postgis;
CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- ---------------------------------------------------------------------
-- 0. Authoritative Coordinate Reference System
--    Zimbabwe Cadastral Gauss Conform 31°E Belt (Masvingo meridian 31°E)
--    Arc 1950 (Clarke 1880 modified), Y positive West, X positive South
-- ---------------------------------------------------------------------
INSERT INTO spatial_ref_sys (srid, auth_name, auth_srid, srtext, proj4text)
VALUES (990031, 'MSU-CLIS', 990031, '',
        '+proj=tmerc +lat_0=0 +lon_0=31 +k=1 +x_0=0 +y_0=0 +axis=wsu '
        '+ellps=clrk80 +towgs84=-143,-90,-294 +units=m +no_defs')
ON CONFLICT (srid) DO NOTHING;

-- ---------------------------------------------------------------------
-- 1. Schemas
-- ---------------------------------------------------------------------
CREATE SCHEMA IF NOT EXISTS lis;
CREATE SCHEMA IF NOT EXISTS lis_ref;

-- Drop existing tables/views if resetting
DROP VIEW IF EXISTS lis.v_parcels_public CASCADE;
DROP TABLE IF EXISTS lis.stage_event CASCADE;
DROP TABLE IF EXISTS lis.parcel CASCADE;
DROP TABLE IF EXISTS lis.app_user CASCADE;
DROP TABLE IF EXISTS lis_ref.stage CASCADE;

-- ---------------------------------------------------------------------
-- 2. Controlled Vocabularies: lis_ref.stage
-- ---------------------------------------------------------------------
CREATE TABLE lis_ref.stage (
    code        text PRIMARY KEY,
    seq         integer UNIQUE NOT NULL,
    name        text NOT NULL,
    color       text NOT NULL,
    description text
);

INSERT INTO lis_ref.stage (code, seq, name, color, description) VALUES
 ('LAYOUT_APPROVED', 1, 'Layout plan approved', '#6b7280', 'Initial town planning layout approved by City Council'),
 ('SURVEYED',        2, 'Surveyed and pegged',   '#f59e0b', 'Cadastral survey completed and boundary beacons pegged'),
 ('ALLOCATED',       3, 'Allocated',             '#38bdf8', 'Beneficiary allocation confirmed in council housing ledger'),
 ('VALUATION_ROLL',  4, 'On valuation roll',     '#f97316', 'Assessed for rates and entered into the municipal valuation roll'),
 ('TITLED',          5, 'Title deed registered', '#22c55e', 'Title deed registered with the Deeds Registry Office');

-- ---------------------------------------------------------------------
-- 3. Users Table: lis.app_user
-- ---------------------------------------------------------------------
CREATE TABLE lis.app_user (
    username      text PRIMARY KEY,
    password_hash text NOT NULL,
    full_name     text NOT NULL,
    role          text NOT NULL CHECK (role IN ('CLERK', 'ADMIN', 'VIEWER')),
    active        boolean NOT NULL DEFAULT true,
    created_at    timestamptz NOT NULL DEFAULT now()
);

-- ---------------------------------------------------------------------
-- 4. Parcels Table: lis.parcel
-- ---------------------------------------------------------------------
CREATE TABLE lis.parcel (
    id               serial PRIMARY KEY,
    upi              text UNIQUE NOT NULL,
    township         text NOT NULL,
    stand_no         text NOT NULL,
    area_m2          numeric(10, 2),
    current_stage    text NOT NULL REFERENCES lis_ref.stage(code),
    stage_entered_at timestamptz NOT NULL DEFAULT now(),
    geom             geometry(Polygon, 990031) NOT NULL,
    created_at       timestamptz NOT NULL DEFAULT now(),
    updated_at       timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT parcel_township_stand_uniq UNIQUE (township, stand_no),
    CONSTRAINT parcel_geom_valid CHECK (ST_IsValid(geom)),
    CONSTRAINT parcel_geom_srid CHECK (ST_SRID(geom) = 990031),
    CONSTRAINT parcel_upi_format CHECK (upi ~ '^[A-Z0-9\-_]+$')
);

CREATE INDEX parcel_geom_gist ON lis.parcel USING GIST (geom);
CREATE INDEX parcel_current_stage_idx ON lis.parcel (current_stage);
CREATE INDEX parcel_township_idx ON lis.parcel (township);
CREATE INDEX parcel_stage_entered_idx ON lis.parcel (stage_entered_at);

-- ---------------------------------------------------------------------
-- 5. Stage Event Audit Log: lis.stage_event
-- ---------------------------------------------------------------------
CREATE TABLE lis.stage_event (
    id                 serial PRIMARY KEY,
    parcel_id          integer NOT NULL REFERENCES lis.parcel(id) ON DELETE CASCADE,
    from_stage         text REFERENCES lis_ref.stage(code),
    to_stage           text NOT NULL REFERENCES lis_ref.stage(code),
    event_date         timestamptz NOT NULL DEFAULT now(),
    recorded_by        text NOT NULL,
    justification_note text,
    source_doc_ref     text,
    created_at         timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX stage_event_parcel_id_idx ON lis.stage_event (parcel_id);
CREATE INDEX stage_event_event_date_idx ON lis.stage_event (event_date);
CREATE INDEX stage_event_to_stage_idx ON lis.stage_event (to_stage);

-- ---------------------------------------------------------------------
-- 6. Trigger: trg_stage_event_sync
--    Enforces sequential progression and justification note when skipping stages.
--    Synchronizes current_stage and stage_entered_at on lis.parcel.
-- ---------------------------------------------------------------------
CREATE OR REPLACE FUNCTION lis.trg_stage_event_sync_fn()
RETURNS trigger AS $$
DECLARE
    v_current_stage text;
    v_from_seq      integer;
    v_to_seq        integer;
    v_from_code     text;
BEGIN
    -- Determine the current stage of the parcel
    SELECT current_stage INTO v_current_stage
    FROM lis.parcel
    WHERE id = NEW.parcel_id;

    v_from_code := COALESCE(NEW.from_stage, v_current_stage);

    -- Get sequences for validation
    IF v_from_code IS NOT NULL THEN
        SELECT seq INTO v_from_seq FROM lis_ref.stage WHERE code = v_from_code;
    ELSE
        v_from_seq := 0;
    END IF;

    SELECT seq INTO v_to_seq FROM lis_ref.stage WHERE code = NEW.to_stage;

    IF v_to_seq IS NULL THEN
        RAISE EXCEPTION 'Target stage "%" does not exist in lis_ref.stage', NEW.to_stage
            USING ERRCODE = 'foreign_key_violation';
    END IF;

    -- Enforce sequential rule:
    -- If skipping forward more than 1 stage OR moving backward, justification note is required
    IF (v_to_seq > v_from_seq + 1) OR (v_to_seq < v_from_seq) THEN
        IF NEW.justification_note IS NULL OR length(trim(NEW.justification_note)) < 5 THEN
            RAISE EXCEPTION 'Stage skipping from "%" to "%" requires an audit justification note of at least 5 characters.',
                COALESCE(v_from_code, 'START'), NEW.to_stage
                USING ERRCODE = 'check_violation';
        END IF;
    END IF;

    -- Update parcel current stage and entry timestamp
    UPDATE lis.parcel
    SET current_stage    = NEW.to_stage,
        stage_entered_at = NEW.event_date,
        updated_at       = now()
    WHERE id = NEW.parcel_id;

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_stage_event_sync
AFTER INSERT ON lis.stage_event
FOR EACH ROW
EXECUTE FUNCTION lis.trg_stage_event_sync_fn();

-- ---------------------------------------------------------------------
-- 7. Non-personal Public View: lis.v_parcels_public
-- ---------------------------------------------------------------------
CREATE OR REPLACE VIEW lis.v_parcels_public AS
SELECT
    p.id,
    p.upi,
    p.township,
    p.stand_no,
    p.area_m2,
    p.current_stage,
    s.name AS stage_name,
    s.seq AS stage_seq,
    s.color AS stage_color,
    p.stage_entered_at,
    ROUND(EXTRACT(EPOCH FROM (now() - p.stage_entered_at)) / (86400 * 30.4375), 1) AS months_in_stage,
    CASE WHEN p.stage_entered_at < (now() - INTERVAL '12 months') THEN true ELSE false END AS is_stalled,
    p.geom
FROM lis.parcel p
JOIN lis_ref.stage s ON p.current_stage = s.code;

-- ---------------------------------------------------------------------
-- 8. Grants for API Role (lis_api)
-- ---------------------------------------------------------------------
DO $$
BEGIN
   IF EXISTS (SELECT FROM pg_catalog.pg_roles WHERE rolname = 'lis_api') THEN
      GRANT USAGE ON SCHEMA lis, lis_ref TO lis_api;
      GRANT SELECT ON ALL TABLES IN SCHEMA lis_ref TO lis_api;
      GRANT SELECT ON lis.v_parcels_public TO lis_api;
      GRANT SELECT, INSERT, UPDATE, DELETE ON lis.parcel, lis.stage_event, lis.app_user TO lis_api;
      GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA lis TO lis_api;
   END IF;
END
$$;
